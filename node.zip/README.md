# ComfyUI-SpriteSheetMaker
The sprite sheet maker node is a simple way to create sprite sheets and image grids.
# Install
1. goto ComfyUI/custom_nodes dir in terminal(cmd)
2. git clone https://github.com/OSAnimate/ComfyUI-SpriteSheetMaker.git
3. Restart ComfyUI
